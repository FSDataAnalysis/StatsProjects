
%%% first load the annealed and aged sample 
%%%% The annealed should have a vector called: dFAD80_annealed
%%%% The aged should have a vector called: dFAD80_aged

%% aged is column 1


% names_ag={'ddm_clean_ag', 'distance_dWA_ag', 'height_dWA_ag'};
% names_an={'ddm_clean_an', 'distance_dWA_an', 'height_dWA_an'};
% 
% Stats=struct;
% labels={'ddm', 'dWA', 'dWA'};


values_ag={ddm_clean_ag, distance_dWA_ag, height_dWA_ag}; 
values_an={ddm_clean_an, distance_dWA_an, height_dWA_an}; 


%%%%%%%%%%%%%%%%%% check how large %%%%%%%%%%%%%%%%%%%%%%


