function [result_old_is, result_new_is, flag1]=GetDoneTriple(xxx_data_old, xxx_data_new, ...
                                                              Remove_outliers_on)

    if Remove_outliers_on==1

        Data_input=xxx_data_old;
        Remove_Outliers;
        xxx_data_old=Data_output;
        
        Data_input=xxx_data_new;
        Remove_Outliers;
        xxx_data_new=Data_output;

    end

    ll_new=length(xxx_data_new);
    ll_aged=length(xxx_data_old);

    if ll_new==ll_aged
        flag1=1;
        largest_is=xxx_data_old;
        smallest_is=xxx_data_new; 
        
    elseif ll_new>ll_aged
        
        largest_is=xxx_data_new;
        smallest_is=xxx_data_old;
        flag1=0;
    else
        largest_is=xxx_data_old;
        smallest_is=xxx_data_new;
        flag1=2;
    end
    
    
    %%%% turn into Mydata %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (flag1==0)||(flag1==2)

        ratio_is=length(largest_is)/length(smallest_is);

        floor_ratio=floor(ratio_is);

        largest_is_short=largest_is(1:(length(smallest_is)*floor_ratio));

        reshape_vector=reshape(largest_is_short,floor_ratio,[]);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        average_largest_short = (sum(reshape_vector,1)./size(reshape_vector,1))';

        %%%% first get the percentage of interest:

        Mydata=[];

        if (flag1==2)  %% aged has more samples

            result_old_is= average_largest_short;   % aged samples Mydata(:,1)=
            result_new_is=smallest_is;             % new samples Mydata(:,2)=

        else   %%%% new has more samples 

            result_new_is=average_largest_short;             % aged samples
            result_old_is=smallest_is;   % new samples

        end

    else

        result_new_is=xxx_data_new;             % aged samples
        result_old_is=xxx_data_old;   % new samples

    end


end




