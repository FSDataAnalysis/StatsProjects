
% clear
% Data_input=input

%%%% To run this code you need to name the vector for which the outliers are to be removed Vector_in;
% Data_input=Vector_in;

Data_input=Data_input';
av=mean(Data_input);
stnd=std(Data_input);
L=size(Data_input,1);
tst = icdf('normal',1-1/(4*L),0,1);
tst_data=(Data_input-av)/stnd;
[RR,C]=find(tst_data>tst);
excluded=Data_input(RR,:);
Data_input(RR,:)=[];

cournter_is = 0;

while isempty(excluded)~=1
    
    av=mean(Data_input); stnd=std(Data_input);
    L=size(Data_input,1);
    tst = icdf('normal',1-1/(4*L),0,1);
    tst_data=(Data_input-av)/stnd;
    [RR,C]=find(tst_data>tst);
    excluded=Data_input(RR,:);
    Data_input(RR,:)=[];
    cournter_is = 1+cournter_is;
end


NumberOfOutliersVector=cournter_is;
Data_output=Data_input;

%%% Tests %%%%%%

%%% test for normality 
%%% 1)  h = chi2gof(Data_output)
%%% 2)  h = jbtest(Data_output)
%%% 3) h = normplot(Data_output)

