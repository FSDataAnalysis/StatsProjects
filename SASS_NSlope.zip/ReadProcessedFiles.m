
clear all;
clc;



%%%%%%%%%%%% Read folders in present directory %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CurrentDirectory=pwd;

fPath=CurrentDirectory;

if fPath==0, error('no folder selected'), end

Folders = dir(fPath);

Folders_Are = [Folders(:).isdir];

Folders=Folders(Folders_Are);

Folder_list = strcat(fPath, filesep, {Folders.name});

Folder_list_new=[];

counter_foo=1;

%%% get read of names that are ot valid, i.e. . or .. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for iii=1: length(Folder_list)
    
    lll=length(Folder_list{iii});
    
    foo_path=Folder_list{iii};
    
    if foo_path(end)=='.'
    
    else     
        
        Folder_list_new{counter_foo}=foo_path;
        counter_foo=counter_foo+1;
        
    end;
end

counter_foo=counter_foo-1;

number_folders=counter_foo;

folder_name=cell(1,number_folders);



