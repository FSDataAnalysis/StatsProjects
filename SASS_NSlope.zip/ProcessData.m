

%%%%%%%%%%%%%% Get names of folders in current irectory %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ReadProcessedFiles;

%%%%%%%%%%%% Add name of fodlers in cell and then string %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ccc=1:number_folders

    [pathstr, f_name, ext]=fileparts(Folder_list_new{ccc});

    folder_name{ccc}=f_name;
    
    
    Parent_Dir=pwd;
    
    %%%%%% Get into next folder to process %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Child_dir=char(sprintf('%s',Parent_Dir, '\', f_name)); 
    
    cd(Child_dir);
    
    
    %%%% loads data about dFAD, i.e. force of adhesion, percentage and dFAD and work of adhesion
    load ('mydata.mat', 'ddm_clean', 'distance_dWA', 'height_dWA');
    
    name_foo_dFA80= char(sprintf('%s', f_name, '.mat')); 
    
    ddm_clean_an=ddm_clean;
    distance_dWA_an=distance_dWA;
    height_dWA_an=height_dWA;
    
    cd(Parent_Dir);

    save (name_foo_dFA80, 'ddm_clean_an', 'distance_dWA_an', 'height_dWA_an');
    
end
    
    
