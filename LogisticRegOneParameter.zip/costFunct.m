function [jVal, gradient]=costFunct(theta)
    
    %%% load vectors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    load my_vectors;  %% this file contains
    
    %% X vectors, i.e. X_vect_1, X_vect_2, etc. depending on model
    %% Y_vectors with 0/1 values from experimental training data set
    
    NNN=length(X_vect(1,:));
    
    %%%%% hypothesis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    theta_Transpose=theta';
    z=theta_Transpose*X_vect;
    
    %%%%% Logistic regression hypothesis function %%%%%%%%%%%%%%%%%
    g_of_z=1./(1+exp(-z));
    
    h_theta=g_of_z;
    
    %%% cost_function %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    jVal=-1/NNN*sum(Y_vect.*(log(h_theta)) + ...
        (1-Y_vect).*(log(1-h_theta)));
    
    gradient=zeros(2,1);
    
    
    gradient(1)= 1/NNN*(sum((h_theta-Y_vect).*X_vect(1,:))); %%%%
    gradient(2)= 1/NNN*(sum((h_theta-Y_vect).*X_vect(2,:)));
    
end