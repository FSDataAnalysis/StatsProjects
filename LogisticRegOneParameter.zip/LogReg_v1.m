%%%% load data %%%%%
clear all;
clc;

load mydata;

%%%% prepare data vectors for model %%%%%
%%%% REQUIRED VECTORS: 
%%%% Y_vect (0/1)
%%%% X_vect continuous values (sample data set)
%%%% h_theta (Model for Logistic Regression inside function)

MMM=length(R); %%% amount of sample points

X_vect_0=ones(1,MMM);  %%%% The model requries this to be a ones vector
X_vect_1=R;            %%%% The model requries this to be a  parameter

X_vect=[X_vect_0; X_vect_1];
Y_vect=y;

save my_vectors;
%%%% Generate vectors %%%%%%%%%%

%%%% save vectors in my_vectors.mat %%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% NNN=length(R);

options = optimset('GradObj', 'on', 'MaxIter', 200);

initialize_theta=zeros(2,1);

[opt_theta, function_val, exit_flag] = fminunc(@costFunct, ...
    initialize_theta, options);


